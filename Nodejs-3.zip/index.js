const { AoiClient, LoadCommands } = require("aoi.js");

const client = new AoiClient({
  token: "MTI0NTkyNzU3NzA2ODI0MDkxNg.GfTfL3.4dpu69LFhx6oSCED1YoNN9mHxhBP-Imwp-UDvw",
  prefix: "d!",
  intents: ["MessageContent", "Guilds", "GuildMessages"],
  events: ["onMessage", "onInteractionCreate"],
  database: {
    type: "aoi.db",
    db: require("@akarui/aoi.db"),
    dbType: "KeyValue",
    tables: ["main"],
    securityKey: "d04389ea1602be6608ccce0732d685d8",
  }
});

const loader = new LoadCommands(client);
loader.load(client.cmd, "./commands")

client.variables({
  started: "false",
  qslot1: "Nothing",
  qslot2: "Nothing",
  qslot3: "Nothing",
  qslot4: "Nothing",
  qslot5: "Nothing",
  quempegou: "",
  dquempegou: "",
  dslot1: "0",
  dslot2: "0",
  dslot3: "0",
  dslot4: "0",
  dslot5: "0",
  mundo: "1",
  quemb: "",
  vquemb: "",
  moneyquemb: "",
  money: "0",
  ds: "",
  chance: "",
  sp: "0",
  Mcorte: "0",
  Mlevantamento: "0",
  Mrecep: "0",
  Mbloqueio: "0",
  Msaque: "0",
  STforca: "25",
  STvelocidade: "10",
  STvertical: "60",
  STenergia: "100",
  STqi: "70",
  STNMaltura: "0",
  spo: "0",
  chance: "0",
  dadoativado: "false",
  motivoafk: "",
  afk: "false",
  blacklist: "false",
  desativarafk: "false",
  cn: "",
  number: "1",
})